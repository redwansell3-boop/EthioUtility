package com.ethioutility.presentation.screens.tariff

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.ethioutility.R
import com.ethioutility.presentation.components.GlassCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TariffScreen(
    viewModel: TariffViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit
) {
    val electricityTariffs by viewModel.electricityTariffs.collectAsState()
    val waterTariffs by viewModel.waterTariffs.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.tariff_info)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Electricity Tariffs", style = MaterialTheme.typography.headlineSmall)
            electricityTariffs.forEach { tariff ->
                GlassCard {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(tariff.name, style = MaterialTheme.typography.titleMedium)
                        Text(tariff.jsonData.take(200) + "...", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Water Tariffs", style = MaterialTheme.typography.headlineSmall)
            waterTariffs.forEach { tariff ->
                GlassCard {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(tariff.name, style = MaterialTheme.typography.titleMedium)
                        Text(tariff.jsonData.take(200) + "...", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
