package com.ethioutility.presentation.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ethioutility.data.local.database.entity.BillEntity
import com.ethioutility.data.repository.BillRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val billRepository: BillRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val bills: StateFlow<List<BillEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) billRepository.getAllBills()
            else billRepository.searchBills(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun deleteBill(bill: BillEntity) {
        viewModelScope.launch {
            billRepository.deleteBill(bill)
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            billRepository.deleteAllBills()
        }
    }
}
