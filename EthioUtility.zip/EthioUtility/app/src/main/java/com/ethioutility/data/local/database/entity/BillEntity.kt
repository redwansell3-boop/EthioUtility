package com.ethioutility.data.local.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bills")
data class BillEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val meterNumber: String,
    val billType: String, // "electricity" or "water"
    val customerType: String,
    val paymentType: String? = null,
    val previousReading: Double,
    val currentReading: Double,
    val consumption: Double,
    val energyCharge: Double,
    val serviceCharge: Double,
    val demandCharge: Double = 0.0,
    val waterCharge: Double = 0.0,
    val sewerCharge: Double = 0.0,
    val vat: Double,
    val grandTotal: Double,
    val createdAt: Long = System.currentTimeMillis(),
    val month: Int,
    val year: Int
)
