package com.ethioutility.presentation.screens.help

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.ethioutility.R
import com.ethioutility.presentation.components.GlassCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(
    viewModel: HelpViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.help)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            GlassCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("How to Calculate Electricity Bill", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("1. Enter previous and current meter readings\n2. Select customer type\n3. Select payment type (for residential)\n4. Tap Calculate to see the breakdown", style = MaterialTheme.typography.bodyMedium)
                }
            }

            GlassCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("How to Calculate Water Bill", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("1. Enter previous and current meter readings\n2. Select customer type (Domestic, Commercial, Government)\n3. Tap Calculate to see the breakdown including sewer charge", style = MaterialTheme.typography.bodyMedium)
                }
            }

            GlassCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Saving & Sharing", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("After calculation, you can save the bill to history or generate a professional PDF invoice with QR code for sharing.", style = MaterialTheme.typography.bodyMedium)
                }
            }

            GlassCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Security", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("All your data is stored locally on your device with encryption. No internet connection is required.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
