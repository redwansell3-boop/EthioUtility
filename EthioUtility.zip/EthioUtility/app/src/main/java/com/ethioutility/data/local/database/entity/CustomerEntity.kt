package com.ethioutility.data.local.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val meterNumber: String,
    val customerType: String,
    val paymentType: String? = null,
    val phoneNumber: String? = null,
    val address: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
