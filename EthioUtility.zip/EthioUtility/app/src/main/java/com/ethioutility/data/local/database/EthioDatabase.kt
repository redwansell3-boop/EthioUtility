package com.ethioutility.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.ethioutility.data.local.database.converters.DateConverters
import com.ethioutility.data.local.database.dao.BillDao
import com.ethioutility.data.local.database.dao.CustomerDao
import com.ethioutility.data.local.database.dao.SettingsDao
import com.ethioutility.data.local.database.dao.TariffDao
import com.ethioutility.data.local.database.entity.BillEntity
import com.ethioutility.data.local.database.entity.CustomerEntity
import com.ethioutility.data.local.database.entity.SettingsEntity
import com.ethioutility.data.local.database.entity.TariffEntity

@Database(
    entities = [
        CustomerEntity::class,
        BillEntity::class,
        TariffEntity::class,
        SettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(DateConverters::class)
abstract class EthioDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun billDao(): BillDao
    abstract fun tariffDao(): TariffDao
    abstract fun settingsDao(): SettingsDao
}
