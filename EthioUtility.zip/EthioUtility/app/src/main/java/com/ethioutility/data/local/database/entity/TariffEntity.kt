package com.ethioutility.data.local.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tariffs")
data class TariffEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val nameAm: String,
    val category: String, // "electricity" or "water"
    val type: String, // customer type id
    val jsonData: String,
    val lastUpdated: Long = System.currentTimeMillis()
)
