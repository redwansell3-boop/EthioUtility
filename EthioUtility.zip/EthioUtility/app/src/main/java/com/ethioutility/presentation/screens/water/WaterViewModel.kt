package com.ethioutility.presentation.screens.water

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ethioutility.data.local.database.entity.BillEntity
import com.ethioutility.data.model.WaterBill
import com.ethioutility.data.repository.BillRepository
import com.ethioutility.data.repository.PdfRepository
import com.ethioutility.data.repository.TariffRepository
import com.ethioutility.domain.usecase.CalculateWaterUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

@HiltViewModel
class WaterViewModel @Inject constructor(
    private val calculateUseCase: CalculateWaterUseCase,
    private val tariffRepository: TariffRepository,
    private val billRepository: BillRepository,
    private val pdfRepository: PdfRepository
) : ViewModel() {

    private val _state = MutableStateFlow(WaterState())
    val state: StateFlow<WaterState> = _state

    fun onCustomerNameChange(value: String) = _state.update { it.copy(customerName = value) }
    fun onMeterNumberChange(value: String) = _state.update { it.copy(meterNumber = value) }
    fun onPreviousReadingChange(value: String) = _state.update { it.copy(previousReading = value, previousReadingError = null) }
    fun onCurrentReadingChange(value: String) = _state.update { it.copy(currentReading = value, currentReadingError = null) }
    fun onCustomerTypeChange(value: String) = _state.update { it.copy(customerType = value) }

    fun calculate() {
        val current = _state.value
        var hasError = false
        val prev = current.previousReading.toDoubleOrNull()
        val curr = current.currentReading.toDoubleOrNull()

        if (prev == null || prev < 0) {
            _state.update { it.copy(previousReadingError = "Invalid reading") }
            hasError = true
        }
        if (curr == null || curr < 0) {
            _state.update { it.copy(currentReadingError = "Invalid reading") }
            hasError = true
        }
        if (prev != null && curr != null && curr <= prev) {
            _state.update { it.copy(currentReadingError = "Current must be greater than previous") }
            hasError = true
        }
        if (hasError) return

        viewModelScope.launch {
            val tariffEntity = tariffRepository.getTariffByType(current.customerType) ?: return@launch
            val tariffJson = tariffRepository.parseWaterTariff(tariffEntity.jsonData)

            val result = calculateUseCase(
                customerName = current.customerName,
                meterNumber = current.meterNumber,
                customerType = current.customerType,
                previousReading = prev!!,
                currentReading = curr!!,
                tariffJson = tariffJson
            )
            _state.update { it.copy(result = result) }
        }
    }

    fun saveBill() {
        val current = _state.value.result ?: return
        viewModelScope.launch {
            val cal = Calendar.getInstance()
            val bill = BillEntity(
                customerName = current.customerName,
                meterNumber = current.meterNumber,
                billType = "water",
                customerType = current.customerType,
                previousReading = current.previousReading,
                currentReading = current.currentReading,
                consumption = current.consumption,
                waterCharge = current.waterCharge,
                sewerCharge = current.sewerCharge,
                serviceCharge = current.serviceCharge,
                vat = current.vat,
                grandTotal = current.grandTotal,
                month = cal.get(Calendar.MONTH) + 1,
                year = cal.get(Calendar.YEAR)
            )
            billRepository.insertBill(bill)
        }
    }

    fun generatePdf() {
        val current = _state.value.result ?: return
        viewModelScope.launch {
            val cal = Calendar.getInstance()
            val bill = BillEntity(
                customerName = current.customerName,
                meterNumber = current.meterNumber,
                billType = "water",
                customerType = current.customerType,
                previousReading = current.previousReading,
                currentReading = current.currentReading,
                consumption = current.consumption,
                waterCharge = current.waterCharge,
                sewerCharge = current.sewerCharge,
                serviceCharge = current.serviceCharge,
                vat = current.vat,
                grandTotal = current.grandTotal,
                month = cal.get(Calendar.MONTH) + 1,
                year = cal.get(Calendar.YEAR)
            )
            pdfRepository.generateInvoice(bill)
        }
    }
}

data class WaterState(
    val customerName: String = "",
    val meterNumber: String = "",
    val previousReading: String = "",
    val currentReading: String = "",
    val customerType: String = "domestic",
    val previousReadingError: String? = null,
    val currentReadingError: String? = null,
    val result: WaterBill? = null
)
