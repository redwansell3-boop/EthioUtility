package com.ethioutility

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class EthioUtilityApp : Application()
