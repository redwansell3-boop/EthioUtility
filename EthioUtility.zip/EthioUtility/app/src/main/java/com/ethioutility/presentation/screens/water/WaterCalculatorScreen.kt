package com.ethioutility.presentation.screens.water

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.ethioutility.R
import com.ethioutility.presentation.components.GlassCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WaterCalculatorScreen(
    viewModel: WaterViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.water_calculator)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = state.customerName,
                onValueChange = viewModel::onCustomerNameChange,
                label = { Text(stringResource(R.string.customer_name)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = state.meterNumber,
                onValueChange = viewModel::onMeterNumberChange,
                label = { Text(stringResource(R.string.meter_number)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = state.previousReading,
                onValueChange = viewModel::onPreviousReadingChange,
                label = { Text(stringResource(R.string.previous_reading)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = state.previousReadingError != null,
                supportingText = state.previousReadingError?.let { { Text(it) } }
            )

            OutlinedTextField(
                value = state.currentReading,
                onValueChange = viewModel::onCurrentReadingChange,
                label = { Text(stringResource(R.string.current_reading)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = state.currentReadingError != null,
                supportingText = state.currentReadingError?.let { { Text(it) } }
            )

            var expandedType by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = expandedType,
                onExpandedChange = { expandedType = it }
            ) {
                OutlinedTextField(
                    value = state.customerType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.customer_type)) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedType) }
                )
                ExposedDropdownMenu(
                    expanded = expandedType,
                    onDismissRequest = { expandedType = false }
                ) {
                    listOf("domestic", "commercial", "government").forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type.replaceFirstChar { it.uppercase() }) },
                            onClick = {
                                viewModel.onCustomerTypeChange(type)
                                expandedType = false
                            }
                        )
                    }
                }
            }

            Button(
                onClick = viewModel::calculate,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.calculate))
            }

            state.result?.let { bill ->
                GlassCard {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Results", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        ResultRow(stringResource(R.string.consumption), "${bill.consumption} m³")
                        ResultRow(stringResource(R.string.water_charge), "ETB ${String.format("%.2f", bill.waterCharge)}")
                        ResultRow(stringResource(R.string.sewer_charge), "ETB ${String.format("%.2f", bill.sewerCharge)}")
                        ResultRow(stringResource(R.string.service_charge), "ETB ${String.format("%.2f", bill.serviceCharge)}")
                        ResultRow(stringResource(R.string.vat), "ETB ${String.format("%.2f", bill.vat)}")
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        ResultRow(stringResource(R.string.grand_total), "ETB ${String.format("%.2f", bill.grandTotal)}", isBold = true)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = viewModel::saveBill, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.save_bill))
                    }
                    OutlinedButton(onClick = viewModel::generatePdf, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.generate_pdf))
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String, isBold: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = label, style = if (isBold) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.bodyMedium)
        Text(text = value, style = if (isBold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium)
    }
}
