package com.ethioutility.presentation.screens.tariff

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ethioutility.data.local.database.entity.TariffEntity
import com.ethioutility.data.repository.TariffRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TariffViewModel @Inject constructor(
    private val tariffRepository: TariffRepository
) : ViewModel() {

    val electricityTariffs: StateFlow<List<TariffEntity>> = tariffRepository.getElectricityTariffs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val waterTariffs: StateFlow<List<TariffEntity>> = tariffRepository.getWaterTariffs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            tariffRepository.loadDefaultTariffs()
        }
    }
}
