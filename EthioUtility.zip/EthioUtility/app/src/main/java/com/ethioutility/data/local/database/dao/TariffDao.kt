package com.ethioutility.data.local.database.dao

import androidx.room.*
import com.ethioutility.data.local.database.entity.TariffEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TariffDao {
    @Query("SELECT * FROM tariffs WHERE category = :category")
    fun getTariffsByCategory(category: String): Flow<List<TariffEntity>>

    @Query("SELECT * FROM tariffs WHERE type = :type LIMIT 1")
    suspend fun getTariffByType(type: String): TariffEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTariff(tariff: TariffEntity)

    @Query("DELETE FROM tariffs WHERE category = :category")
    suspend fun deleteTariffsByCategory(category: String)
}
