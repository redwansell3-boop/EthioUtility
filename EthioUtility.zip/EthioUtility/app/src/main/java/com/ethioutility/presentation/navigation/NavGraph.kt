package com.ethioutility.presentation.navigation

import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ethioutility.presentation.screens.customers.CustomersScreen
import com.ethioutility.presentation.screens.electricity.ElectricityCalculatorScreen
import com.ethioutility.presentation.screens.help.HelpScreen
import com.ethioutility.presentation.screens.history.HistoryScreen
import com.ethioutility.presentation.screens.home.HomeScreen
import com.ethioutility.presentation.screens.onboarding.OnboardingScreen
import com.ethioutility.presentation.screens.reports.ReportsScreen
import com.ethioutility.presentation.screens.settings.SettingsScreen
import com.ethioutility.presentation.screens.splash.SplashScreen
import com.ethioutility.presentation.screens.tariff.TariffScreen
import com.ethioutility.presentation.screens.water.WaterCalculatorScreen

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Home : Screen("home")
    object Electricity : Screen("electricity")
    object Water : Screen("water")
    object History : Screen("history")
    object Customers : Screen("customers")
    object Reports : Screen("reports")
    object Tariff : Screen("tariff")
    object Settings : Screen("settings")
    object Help : Screen("help")
}

@Composable
fun NavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onSplashFinished = {
                    navController.navigate(Screen.Onboarding.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onNavigateToHome = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToElectricity = { navController.navigate(Screen.Electricity.route) },
                onNavigateToWater = { navController.navigate(Screen.Water.route) },
                onNavigateToHistory = { navController.navigate(Screen.History.route) },
                onNavigateToCustomers = { navController.navigate(Screen.Customers.route) },
                onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                onNavigateToTariff = { navController.navigate(Screen.Tariff.route) },
                onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                onNavigateToHelp = { navController.navigate(Screen.Help.route) }
            )
        }
        composable(Screen.Electricity.route) {
            ElectricityCalculatorScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Water.route) {
            WaterCalculatorScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.History.route) {
            HistoryScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Customers.route) {
            CustomersScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Reports.route) {
            ReportsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Tariff.route) {
            TariffScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Help.route) {
            HelpScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
