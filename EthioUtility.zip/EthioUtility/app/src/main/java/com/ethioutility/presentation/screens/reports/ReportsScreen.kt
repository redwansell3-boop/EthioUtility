package com.ethioutility.presentation.screens.reports

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.ethioutility.R
import com.ethioutility.presentation.components.GlassCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: ReportsViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit
) {
    val monthlyData by viewModel.monthlyData.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.monthly_reports)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            GlassCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.monthly_spending), style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    BarChart(data = monthlyData)
                }
            }

            GlassCard {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.monthly_usage), style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    PieChart(data = monthlyData)
                }
            }

            GlassCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.yearly_spending), style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    LineChart(data = monthlyData)
                }
            }
        }
    }
}

@Composable
fun BarChart(data: List<Pair<String, Double>>) {
    if (data.isEmpty()) return
    val maxValue = data.maxOfOrNull { it.second } ?: 1.0
    val barColor = MaterialTheme.colorScheme.primary

    Canvas(modifier = Modifier.fillMaxWidth().height(200.dp).padding(8.dp)) {
        val barWidth = size.width / (data.size * 2)
        val spacing = barWidth
        data.forEachIndexed { index, (_, value) ->
            val barHeight = (value / maxValue) * size.height * 0.8f
            val x = index * (barWidth + spacing) + spacing
            val y = size.height - barHeight
            drawRect(color = barColor, topLeft = Offset(x, y), size = Size(barWidth, barHeight))
        }
    }
}

@Composable
fun PieChart(data: List<Pair<String, Double>>) {
    if (data.isEmpty()) return
    val total = data.sumOf { it.second }
    val colors = listOf(
        Color(0xFF006C4C), Color(0xFF4D6357), Color(0xFF3D6373),
        Color(0xFFBA1A1A), Color(0xFFFFB4AB), Color(0xFF8BF8C7)
    )

    Canvas(modifier = Modifier.size(200.dp)) {
        var startAngle = 0f
        data.forEachIndexed { index, (_, value) ->
            val sweepAngle = ((value / total) * 360).toFloat()
            drawArc(
                color = colors[index % colors.size],
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = true,
                size = Size(size.width, size.height)
            )
            startAngle += sweepAngle
        }
    }
}

@Composable
fun LineChart(data: List<Pair<String, Double>>) {
    if (data.isEmpty()) return
    val maxValue = data.maxOfOrNull { it.second } ?: 1.0
    val lineColor = MaterialTheme.colorScheme.primary
    val pointColor = MaterialTheme.colorScheme.secondary

    Canvas(modifier = Modifier.fillMaxWidth().height(200.dp).padding(8.dp)) {
        val stepX = size.width / (data.size - 1).coerceAtLeast(1)
        for (i in 0 until data.size - 1) {
            val x1 = i * stepX
            val y1 = size.height - ((data[i].second / maxValue) * size.height * 0.8f).toFloat()
            val x2 = (i + 1) * stepX
            val y2 = size.height - ((data[i + 1].second / maxValue) * size.height * 0.8f).toFloat()
            drawLine(color = lineColor, start = Offset(x1, y1), end = Offset(x2, y2), strokeWidth = 4f, cap = StrokeCap.Round)
        }
        data.forEachIndexed { index, (_, value) ->
            val x = index * stepX
            val y = size.height - ((value / maxValue) * size.height * 0.8f).toFloat()
            drawCircle(color = pointColor, radius = 8f, center = Offset(x, y))
        }
    }
}
