package com.ethioutility.presentation.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ethioutility.data.repository.BillRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import java.util.Calendar
import javax.inject.Inject

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val billRepository: BillRepository
) : ViewModel() {

    val monthlyData: StateFlow<List<Pair<String, Double>>> = flow {
        val cal = Calendar.getInstance()
        val data = mutableListOf<Pair<String, Double>>()
        for (i in 5 downTo 0) {
            val month = cal.get(Calendar.MONTH) + 1 - i
            val year = cal.get(Calendar.YEAR)
            val adjustedMonth = if (month <= 0) month + 12 else month
            val adjustedYear = if (month <= 0) year - 1 else year
            val total = billRepository.getTotalSpendingByMonth(adjustedMonth, adjustedYear)
            data.add("$adjustedMonth/$adjustedYear" to total)
        }
        emit(data)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
