package com.ethioutility.di

import android.content.Context
import androidx.room.Room
import com.ethioutility.data.local.database.EthioDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import net.sqlcipher.database.SupportFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): EthioDatabase {
        val passphrase = "EthioUtilitySecurePassphrase2024!".toByteArray()
        val factory = SupportFactory(passphrase)

        return Room.databaseBuilder(
            context,
            EthioDatabase::class.java,
            "ethio_utility.db"
        )
            .openHelperFactory(factory)
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideCustomerDao(db: EthioDatabase) = db.customerDao()

    @Provides
    fun provideBillDao(db: EthioDatabase) = db.billDao()

    @Provides
    fun provideTariffDao(db: EthioDatabase) = db.tariffDao()

    @Provides
    fun provideSettingsDao(db: EthioDatabase) = db.settingsDao()
}
