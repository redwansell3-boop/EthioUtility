package com.ethioutility.presentation.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ethioutility.data.repository.BillRepository
import com.ethioutility.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val billRepository: BillRepository
) : ViewModel() {

    val isDarkMode = settingsRepository.isDarkMode
    val language = settingsRepository.language

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setDarkMode(enabled)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            settingsRepository.setLanguage(lang)
        }
    }

    fun resetHistory() {
        viewModelScope.launch {
            billRepository.deleteAllBills()
        }
    }
}
