package com.ethioutility.data.local.database.dao

import androidx.room.*
import com.ethioutility.data.local.database.entity.BillEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY createdAt DESC")
    fun getAllBills(): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE billType = :type ORDER BY createdAt DESC")
    fun getBillsByType(type: String): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE month = :month AND year = :year ORDER BY createdAt DESC")
    fun getBillsByMonthYear(month: Int, year: Int): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE customerName LIKE '%' || :query || '%' OR meterNumber LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchBills(query: String): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE id = :id")
    suspend fun getBillById(id: Long): BillEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: BillEntity): Long

    @Delete
    suspend fun deleteBill(bill: BillEntity)

    @Query("DELETE FROM bills")
    suspend fun deleteAllBills()

    @Query("SELECT SUM(grandTotal) FROM bills WHERE month = :month AND year = :year")
    suspend fun getTotalSpendingByMonth(month: Int, year: Int): Double?

    @Query("SELECT SUM(consumption) FROM bills WHERE month = :month AND year = :year AND billType = :type")
    suspend fun getTotalConsumptionByMonth(month: Int, year: Int, type: String): Double?

    @Query("SELECT DISTINCT year FROM bills ORDER BY year DESC")
    fun getAvailableYears(): Flow<List<Int>>
}
