package com.ethioutility.di

import android.content.Context
import com.ethioutility.data.local.database.dao.BillDao
import com.ethioutility.data.local.database.dao.CustomerDao
import com.ethioutility.data.local.database.dao.SettingsDao
import com.ethioutility.data.local.database.dao.TariffDao
import com.ethioutility.data.local.datastore.AppDataStore
import com.ethioutility.data.repository.BillRepository
import com.ethioutility.data.repository.CustomerRepository
import com.ethioutility.data.repository.PdfRepository
import com.ethioutility.data.repository.SettingsRepository
import com.ethioutility.data.repository.TariffRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideCustomerRepository(dao: CustomerDao): CustomerRepository {
        return CustomerRepository(dao)
    }

    @Provides
    @Singleton
    fun provideBillRepository(dao: BillDao): BillRepository {
        return BillRepository(dao)
    }

    @Provides
    @Singleton
    fun provideTariffRepository(
        @ApplicationContext context: Context,
        dao: TariffDao
    ): TariffRepository {
        return TariffRepository(context, dao)
    }

    @Provides
    @Singleton
    fun provideSettingsRepository(
        dataStore: AppDataStore,
        dao: SettingsDao
    ): SettingsRepository {
        return SettingsRepository(dataStore, dao)
    }

    @Provides
    @Singleton
    fun providePdfRepository(@ApplicationContext context: Context): PdfRepository {
        return PdfRepository(context)
    }
}
