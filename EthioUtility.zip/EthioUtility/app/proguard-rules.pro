# ProGuard rules
-keepclassmembers class * extends androidx.room.RoomDatabase {
    <init>();
}
-keep class com.ethioutility.data.local.database.entity.** { *; }
-keep class com.ethioutility.data.model.** { *; }
